package com.ecommerce.tests;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
 
@DisplayName("JUnit 5 Nested Example")
@RunWith(JUnitPlatform.class)
public class NestedCases {
 
    
    static void beforeAll() {
        System.out.println("Before all test methods");
    }
 

    void beforeEach() {
        System.out.println("Before each test method");
    }
 

    void afterEach() {
        System.out.println("After each test method");
    }

    static void afterAll() {
        System.out.println("After all test methods");
    }
 
    
    @DisplayName("Tests for the method A")
    class A {
 
        void beforeEach() {
            System.out.println("Before each test method of the A class");
        }
 
        void afterEach() {
            System.out.println("After each test method of the A class");
        }
 
        @Test
        @DisplayName("Example test for method A")
        void sampleTestForMethodA() {
            System.out.println("Example test for method A");
        }
 
      
        @DisplayName("When X is true")
        class WhenX {
 
           
            void beforeEach() {
                System.out.println("Before each test method of the WhenX class");
            }
 
         
            void afterEach() {
                System.out.println("After each test method of the WhenX class");
            }
 
          
            @DisplayName("Example test for method A when X is true")
            void sampleTestForMethodAWhenX() {
                System.out.println("Example test for method A when X is true");
            }
        }
    }
}

